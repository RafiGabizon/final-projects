function greet() {
    alert("Hello, welcome to my static site!");
}
