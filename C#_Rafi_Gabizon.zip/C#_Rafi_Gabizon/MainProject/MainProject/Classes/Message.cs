using System;

namespace MainProject
{
    public class Message
    {
        public string From { get; set; } = string.Empty;
        public string To { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public DateTime SentTime { get; set; }
        public bool IsRead { get; set; } = false; 

        public Message(string from, string body, string to)
        {
            From = from;
            To = to;
            Body = body;
            SentTime = DateTime.Now;
            IsRead = false;
        }

        public Message(string from, string to, string body, DateTime sentTime)
        {
            From = from;
            To = to;
            Body = body;
            SentTime = sentTime;
            IsRead = false;
        }

        public Message() { }

        public string GetMessageDetails()
        {
            return $"מאת: {From}, אל: {To}, זמן: {SentTime:dd/MM/yyyy HH:mm}";
        }

        public void MarkAsRead()
        {
            IsRead = true;
        }
    }
}