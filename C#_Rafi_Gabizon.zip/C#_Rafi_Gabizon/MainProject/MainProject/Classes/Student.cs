using MainProject.Enums;
using System;

namespace MainProject.Classes
{
    public class Student : User
    {
        public string StudentId { get; set; } = string.Empty; 
        public int Semester { get; set; } = 1; 
        public string Department { get; set; } = string.Empty; 

        public Student()
        {
            Role = UserType.Student;
        }

        public Student(string name, string familyName, string studentId)
        {
            Name = name;
            FamilyName = familyName;
            StudentId = studentId;
            Role = UserType.Student;
        }

        public override string GetUserDetails()
        {
            return $"{base.GetUserDetails()}, מספר סטודנט: {StudentId}, סמסטר: {Semester}";
        }

        public void UpdateSemester(int newSemester)
        {
            if (newSemester > 0 && newSemester <= 12)
            {
                Semester = newSemester;
            }
            else
            {
                throw new ArgumentException("מספר סמסטר אינו חוקי");
            }
        }
    }
}