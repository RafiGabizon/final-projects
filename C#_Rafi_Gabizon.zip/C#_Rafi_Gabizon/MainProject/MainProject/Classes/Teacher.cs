using MainProject.Enums;
using System.Collections.Generic;
using System;

namespace MainProject.Classes
{
    public class Teacher : User
    {
        public string StaffId { get; set; } = string.Empty; 
        public DateTime HireDate { get; set; } = DateTime.Now; 
        public List<string> Courses { get; set; } = new List<string>(); 

        public Teacher()
        {
            Role = UserType.Teaching; 
        }

        public Teacher(string name, string familyName, string staffId, UserType role)
        {
            Name = name;
            FamilyName = familyName;
            StaffId = staffId;
            Role = role;
        }

        public override string GetUserDetails()
        {
            return $"{base.GetUserDetails()}, מספר עובד: {StaffId}, תאריך העסקה: {HireDate:dd/MM/yyyy}";
        }

        public void AddCourse(string courseName)
        {
            if (!string.IsNullOrEmpty(courseName) && !Courses.Contains(courseName))
            {
                Courses.Add(courseName);
            }
        }

        public bool RemoveCourse(string courseName)
        {
            return Courses.Remove(courseName);
        }

        public string GetCoursesAsString()
        {
            return string.Join(", ", Courses);
        }
    }
}