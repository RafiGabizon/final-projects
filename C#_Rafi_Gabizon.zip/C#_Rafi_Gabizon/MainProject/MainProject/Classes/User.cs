using MainProject.Enums;
using System;

namespace MainProject.Classes
{
    public class User
    {
        public string Name { get; set; } = string.Empty;
        public string FamilyName { get; set; } = string.Empty;
        public string EmailAddress { get; set; } = string.Empty;
        public string PersonalId { get; set; } = string.Empty;
        public string? Avatar { get; set; } 
        public UserType Role { get; set; } 
        public DateTime RegisterDate { get; set; } = DateTime.Now; 
        public string GetFullName()
        {
            return $"{Name} {FamilyName}";
        }

        public virtual string GetUserDetails()
        {
            return $"שם: {GetFullName()}, תפקיד: {GetRoleDescription()}";
        }

        public string GetRoleDescription()
        {
            switch (Role)
            {
                case UserType.Student:
                    return "סטודנט";
                case UserType.Teaching:
                    return "מתרגל";
                case UserType.Lecturer:
                    return "מרצה";
                case UserType.DepartmentHead:
                    return "ראש מחלקה";
                default:
                    return "לא מוגדר";
            }
        }
        
        public bool ValidatePassword(string password)
        {
            return !string.IsNullOrEmpty(password) && password.Length >= 6;
        }
    }
}