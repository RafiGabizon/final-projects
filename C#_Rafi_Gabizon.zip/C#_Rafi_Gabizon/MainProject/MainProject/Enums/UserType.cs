namespace MainProject.Enums
{

    public enum UserType
    {

        Student,


        Teaching,


        Lecturer,


        DepartmentHead
    }
}