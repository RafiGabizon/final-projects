using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using MainProject.Classes;
using MainProject.Enums;

namespace MainProject
{
    public partial class Form1 : Form
    {
        private const string DATA_FILE = "university_users.txt";
        private Panel contentPanel = new Panel();
        private Panel navigationPanel = new Panel();
        private User? activeUser;

        public Form1()
        {
            InitializeComponent();
            SetupApplicationUI();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayWelcomeScreen();
            FileHandler.LogAction("אפליקציה נפתחה");
        }

        private void AddNavigationButton(string buttonText, EventHandler clickEvent)
        {
            Button navButton = new Button
            {
                Text = buttonText,
                Dock = DockStyle.Top,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Height = 60,
                Font = new Font("Segoe UI", 12F, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = Color.FromArgb(60, 60, 80), 
                Cursor = Cursors.Hand
            };
            navButton.Click += clickEvent;
            navigationPanel.Controls.Add(navButton);
        }

        private void SetupApplicationUI()
        {
            this.Text = "מערכת מידע אקדמית";
            this.Size = new Size(1500, 900);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;

            this.BackColor = Color.FromArgb(230, 235, 240);

            TableLayoutPanel mainLayoutPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1
            };
            mainLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F)); 
            mainLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 75F));
            this.Controls.Add(mainLayoutPanel);

            navigationPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(40, 50, 70)
            };
            mainLayoutPanel.Controls.Add(navigationPanel, 0, 0);

            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(240, 245, 250)
            };
            mainLayoutPanel.Controls.Add(contentPanel, 1, 0);

            Label logoLabel = new Label
            {
                Text = "מערכת\nאקדמית",
                Font = new Font("Segoe UI", 24F, FontStyle.Bold),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 150
            };
            navigationPanel.Controls.Add(logoLabel);

            AddNavigationButton("התחברות למערכת", (sender, e) => ShowLoginScreen(), Color.FromArgb(50, 120, 180)); // כחול כהה
            AddNavigationButton("הרשמה למערכת", (sender, e) => ShowRegistrationScreen(), Color.FromArgb(70, 130, 180)); // כחול בינוני

            DisplayWelcomeScreen();
        }

        private void AddNavigationButton(string buttonText, EventHandler clickEvent, Color backgroundColor)
        {
            Button navButton = new Button
            {
                Text = buttonText,
                Dock = DockStyle.Top,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Height = 60,
                Font = new Font("Segoe UI", 12F, FontStyle.Regular),
                ForeColor = Color.White,
                BackColor = backgroundColor,
                Cursor = Cursors.Hand
            };
            navButton.Click += clickEvent;
            navigationPanel.Controls.Add(navButton);
        }

        private void AddCustomButton(string buttonText, Color buttonColor, Color textColor, EventHandler clickEvent)
        {
            Button customButton = new Button
            {
                Text = buttonText,
                Dock = DockStyle.Top,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Height = 60,
                Font = new Font("Segoe UI", 14F, FontStyle.Regular),
                ForeColor = textColor,
                BackColor = buttonColor,
                Cursor = Cursors.Hand,
                Margin = new Padding(10)
            };
            customButton.Click += clickEvent;
            navigationPanel.Controls.Add(customButton);
        }

        private void DisplayWelcomeScreen()
        {
            contentPanel.Controls.Clear();
            Label welcomeLabel = new Label
            {
                Text = "ברוכים הבאים למערכת האקדמית",
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 24F, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 50, 70) 
            };
            contentPanel.Controls.Add(welcomeLabel);
        }

        private void ShowLoginScreen()
        {
            contentPanel.Controls.Clear();

            TableLayoutPanel loginLayoutPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(50)
            };
            loginLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            loginLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            loginLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            loginLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));

            TextBox emailInput = CreateStyledInput("כתובת דוא\"ל");
            TextBox passwordInput = CreateStyledInput("סיסמה");
            passwordInput.PasswordChar = '*';
            passwordInput.UseSystemPasswordChar = true;

            Button loginButton = new Button
            {
                Text = "כניסה למערכת",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180), 
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            loginButton.Click += (sender, e) => AuthenticateUser(emailInput.Text, passwordInput.Text);

            loginLayoutPanel.Controls.Add(new Label
            {
                Text = "התחברות למערכת",
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            }, 0, 0);
            loginLayoutPanel.Controls.Add(emailInput, 0, 1);
            loginLayoutPanel.Controls.Add(passwordInput, 0, 2);
            loginLayoutPanel.Controls.Add(loginButton, 0, 3);

            contentPanel.Controls.Add(loginLayoutPanel);
        }

        private void ShowRegistrationScreen()
        {
            contentPanel.Controls.Clear();

            TableLayoutPanel registerLayoutPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 9,
                Padding = new Padding(50)
            };

            for (int i = 0; i < 9; i++)
            {
                registerLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 9));
            }

            TextBox nameInput = CreateStyledInput("שם פרטי");
            TextBox familyNameInput = CreateStyledInput("שם משפחה");
            TextBox emailInput = CreateStyledInput("כתובת דוא\"ל");
            TextBox passwordInput = CreateStyledInput("סיסמה");
            passwordInput.PasswordChar = '*';
            passwordInput.UseSystemPasswordChar = true;

            ComboBox roleSelector = new ComboBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 12F),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.White
            };
            roleSelector.Items.AddRange(new object[] { "סטודנט", "מתרגל", "מרצה", "ראש מחלקה" });

            PictureBox userImagePreview = new PictureBox
            {
                SizeMode = PictureBoxSizeMode.StretchImage,
                Height = 100,
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.Fixed3D,
                BackColor = Color.White
            };

            Button uploadImageButton = new Button
            {
                Text = "בחירת תמונת פרופיל",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(70, 130, 180), // כחול בינוני
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            uploadImageButton.Click += (sender, e) => SelectProfileImage(userImagePreview);

            Button registerButton = new Button
            {
                Text = "הרשמה",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180), // כחול כהה
                ForeColor = Color.White,
                Height = 100,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };

            registerButton.Click += (sender, e) => RegisterNewUser(
                nameInput.Text,
                familyNameInput.Text,
                emailInput.Text,
                passwordInput.Text,
                roleSelector.SelectedItem?.ToString() ?? string.Empty,
                userImagePreview.ImageLocation
            );

            registerLayoutPanel.Controls.Add(new Label
            {
                Text = "הרשמה למערכת",
                Font = new Font("Segoe UI", 20F, FontStyle.Bold),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            }, 0, 0);
            registerLayoutPanel.Controls.Add(nameInput, 0, 1);
            registerLayoutPanel.Controls.Add(familyNameInput, 0, 2);
            registerLayoutPanel.Controls.Add(emailInput, 0, 3);
            registerLayoutPanel.Controls.Add(passwordInput, 0, 4);
            registerLayoutPanel.Controls.Add(roleSelector, 0, 5);
            registerLayoutPanel.Controls.Add(userImagePreview, 0, 6);
            registerLayoutPanel.Controls.Add(uploadImageButton, 0, 7);
            registerLayoutPanel.Controls.Add(registerButton, 0, 8);

            contentPanel.Controls.Add(registerLayoutPanel);
        }

        private string? SelectProfileImage(PictureBox pictureBox)
        {
            using (OpenFileDialog imageDialog = new OpenFileDialog())
            {
                imageDialog.Filter = "קבצי תמונה|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
                imageDialog.Title = "בחירת תמונת פרופיל";

                if (imageDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox.ImageLocation = imageDialog.FileName;
                    return imageDialog.FileName;
                }
            }
            return string.Empty;
        }

        private void RegisterNewUser(string name, string familyName, string email, string password, string role, string imagePath)
        {
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(familyName) ||
                string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(role))
            {
                MessageBox.Show("יש למלא את כל שדות החובה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (UserExists(email))
            {
                MessageBox.Show("משתמש עם כתובת דוא\"ל זו כבר קיים במערכת", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string GenerateUniqueId(string userRole)
            {
                string prefix;
                switch (userRole)
                {
                    case "סטודנט":
                        prefix = "STU";
                        break;
                    case "מתרגל":
                        prefix = "TA";
                        break;
                    case "מרצה":
                        prefix = "PROF";
                        break;
                    case "ראש מחלקה":
                        prefix = "HEAD";
                        break;
                    default:
                        prefix = "USR";
                        break;
                }

                return $"{prefix}{DateTime.Now.Year}{new Random().Next(1000, 9999)}";
            }

            string uniqueId = GenerateUniqueId(role);

            string userRecord = $"{name},{familyName},{email},{password},{role},{uniqueId},{imagePath}";
            File.AppendAllText(DATA_FILE, userRecord + Environment.NewLine);

            MessageBox.Show("ההרשמה הושלמה בהצלחה!", "הצלחה", MessageBoxButtons.OK, MessageBoxIcon.Information);
            FileHandler.LogAction($"משתמש חדש נרשם: {email}, תפקיד: {role}");

            UserType userTypeEnum = ConvertStringToUserType(role);
            activeUser = CreateUserObject(new[] { name, familyName, email, password, role, uniqueId, imagePath }, userTypeEnum);

            NavigateToMainPage(userTypeEnum, activeUser);
        }

        private TextBox CreateStyledInput(string placeholder)
        {
            TextBox textBox = new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 12F),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                ForeColor = Color.Gray
            };

            textBox.Enter += (sender, e) =>
            {
                if (textBox.Text == placeholder)
                {
                    textBox.Text = "";
                    textBox.ForeColor = Color.Black;
                }
            };

            textBox.Leave += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    textBox.Text = placeholder;
                    textBox.ForeColor = Color.Gray;
                }
            };

            textBox.Text = placeholder;
            return textBox;
        }

        private void AuthenticateUser(string email, string password)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("יש להזין כתובת דוא\"ל וסיסמה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!File.Exists(DATA_FILE))
            {
                MessageBox.Show("לא נמצאו נתוני משתמשים במערכת", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string[] usersData = File.ReadAllLines(DATA_FILE);

            foreach (string userData in usersData)
            {
                string[] fields = userData.Split(',');

                if (fields.Length >= 6 && fields[2] == email && fields[3] == password)
                {
                    UserType userRole = ConvertStringToUserType(fields[4]);
                    activeUser = CreateUserObject(fields, userRole);

                    MessageBox.Show($"ברוך הבא, {activeUser.Name}!", "התחברות מוצלחת", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    FileHandler.LogAction($"משתמש התחבר: {email}, תפקיד: {fields[4]}");

                    NavigateToMainPage(activeUser.Role, activeUser);
                    return;
                }
            }

            MessageBox.Show("כתובת דוא\"ל או סיסמה שגויים", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private User CreateUserObject(string[] userData, UserType userRole)
        {
            switch (userRole)
            {
                case UserType.Student:
                    return new Student
                    {
                        Name = userData[0],
                        FamilyName = userData[1],
                        EmailAddress = userData[2],
                        PersonalId = userData[5],
                        StudentId = userData[5],
                        Role = userRole,
                        Avatar = userData.Length > 6 ? userData[6] : null
                    };
                case UserType.Teaching:
                case UserType.Lecturer:
                case UserType.DepartmentHead:
                    return new Teacher
                    {
                        Name = userData[0],
                        FamilyName = userData[1],
                        EmailAddress = userData[2],
                        PersonalId = userData[5],
                        StaffId = userData[5],
                        Role = userRole,
                        Avatar = userData.Length > 6 ? userData[6] : null
                    };
                default:
                    return new User
                    {
                        Name = userData[0],
                        FamilyName = userData[1],
                        EmailAddress = userData[2],
                        PersonalId = userData[5],
                        Role = userRole,
                        Avatar = userData.Length > 6 ? userData[6] : null
                    };
            }
        }

        private bool UserExists(string email)
        {
            if (File.Exists(DATA_FILE))
            {
                string[] users = File.ReadAllLines(DATA_FILE);
                foreach (string user in users)
                {
                    string[] userFields = user.Split(',');
                    if (userFields.Length >= 3 && userFields[2] == email)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        private UserType ConvertStringToUserType(string role)
        {
            switch (role)
            {
                case "סטודנט":
                    return UserType.Student;
                case "מתרגל":
                    return UserType.Teaching;
                case "מרצה":
                    return UserType.Lecturer;
                case "ראש מחלקה":
                    return UserType.DepartmentHead;
                default:
                    throw new ArgumentException("תפקיד לא מוכר", nameof(role));
            }
        }

        private void NavigateToMainPage(UserType userRole, User user)
        {
            MainPage mainPage = new MainPage(userRole, this, user);
            mainPage.FormClosed += (s, args) => this.Show();
            mainPage.Show();
            this.Hide();
        }
    }
}