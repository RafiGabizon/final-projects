using System;
using System.Drawing;
using System.Windows.Forms;

namespace MainProject.Forms
{
    /// מסך התחברות נפרד לשימוש הפרויקט
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            this.Text = "התחברות למערכת";
            this.Size = new Size(400, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.FromArgb(240, 245, 250);
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Font = new Font("Segoe UI", 10F);

            TableLayoutPanel mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(20)
            };
            this.Controls.Add(mainPanel);

            Label titleLabel = new Label
            {
                Text = "כניסה למערכת",
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(40, 50, 70),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };
            mainPanel.Controls.Add(titleLabel);

            TextBox emailInput = new TextBox
            {
                PlaceholderText = "כתובת דוא\"ל",
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 12F),
                Margin = new Padding(0, 10, 0, 10)
            };
            mainPanel.Controls.Add(emailInput);

            TextBox passwordInput = new TextBox
            {
                PlaceholderText = "סיסמה",
                PasswordChar = '●',
                UseSystemPasswordChar = true,
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 12F),
                Margin = new Padding(0, 0, 0, 20)
            };
            mainPanel.Controls.Add(passwordInput);

            Button loginButton = new Button
            {
                Text = "התחבר",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };

            loginButton.Click += (sender, e) =>
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            };

            mainPanel.Controls.Add(loginButton);
        }
    }
}