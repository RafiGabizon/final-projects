using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MainProject.Classes;
using MainProject.Enums;

namespace MainProject
{
    public partial class MainPage : Form
    {
        private Form1 loginForm;
        private UserType userRole;
        private User currentUser;
        private ListView? userSearchResults;
        private ListView? communicationsList;

        public MainPage(UserType userType, Form1 loginForm, User user)
        {
            InitializeComponent();
            this.loginForm = loginForm;
            userRole = userType;
            currentUser = user;
            userSearchResults = new ListView();
            communicationsList = new ListView();
            SetupModernInterface();
        }

        private void SetupModernInterface()
        {
            this.Text = "מערכת מידע אקדמית";
            this.Size = new Size(1400, 900);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(0)));
            this.RightToLeft = RightToLeft.Yes;
            this.RightToLeftLayout = true;

            this.BackColor = Color.FromArgb(240, 245, 250);

            TableLayoutPanel mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            this.Controls.Add(mainLayout);

            Panel topPanel = CreateHeaderPanel();
            mainLayout.Controls.Add(topPanel, 0, 0);

            TabControl mainTabControl = CreateMainTabController();
            mainLayout.Controls.Add(mainTabControl, 0, 1);

            mainTabControl.TabPages.Add(CreateTabView("פרופיל אישי", CreateProfilePanel()));
            mainTabControl.TabPages.Add(CreateTabView("הודעות", CreateMessagesPanel()));
            mainTabControl.TabPages.Add(CreateTabView("תפריט פונקציות", CreateFunctionalityPanel()));
            mainTabControl.TabPages.Add(CreateTabView("חיפוש אנשים", CreatePeopleSearchPanel()));
            mainTabControl.TabPages.Add(CreateTabView("הגדרות", CreateSettingsPanel()));

            if (mainTabControl.TabPages.Count > 0)
            {
                mainTabControl.SelectedIndex = 0;
            }
        }

        private Control CreateSettingsPanel()
        {
            Panel settingsPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            CheckBox darkModeOption = new CheckBox
            {
                Text = "מצב כהה",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 12F),
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            darkModeOption.CheckedChanged += (sender, e) => ApplyDarkMode(darkModeOption.Checked);
            settingsPanel.Controls.Add(darkModeOption);

            TrackBar fontSizeSlider = new TrackBar
            {
                Minimum = 8,
                Maximum = 24,
                Value = 12,
                TickStyle = TickStyle.BottomRight,
                Dock = DockStyle.Top,
                Margin = new Padding(0, 20, 0, 0)
            };
            fontSizeSlider.Scroll += (sender, e) => ChangeFontSize(fontSizeSlider.Value);
            settingsPanel.Controls.Add(fontSizeSlider);

            Label fontSizeLabel = new Label
            {
                Text = "גודל גופן: 12",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 12F),
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            fontSizeSlider.ValueChanged += (sender, e) => fontSizeLabel.Text = $"גודל גופן: {fontSizeSlider.Value}";
            settingsPanel.Controls.Add(fontSizeLabel);

            Button saveSettingsButton = new Button
            {
                Text = "שמור הגדרות",
                Dock = DockStyle.Bottom,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Height = 40,
                Margin = new Padding(0, 20, 0, 0)
            };
            saveSettingsButton.Click += (sender, e) => MessageBox.Show("ההגדרות נשמרו בהצלחה", "הודעת מערכת", MessageBoxButtons.OK, MessageBoxIcon.Information);
            settingsPanel.Controls.Add(saveSettingsButton);

            return settingsPanel;
        }

        private void ApplyDarkMode(bool isDarkMode)
        {
            this.BackColor = isDarkMode ? Color.FromArgb(40, 40, 40) : Color.FromArgb(240, 245, 250);

            foreach (Control control in this.Controls)
            {
                if (control is Panel)
                {
                    control.BackColor = isDarkMode ? Color.FromArgb(60, 60, 60) : Color.FromArgb(240, 245, 250);
                    control.ForeColor = isDarkMode ? Color.White : Color.Black;
                }
            }
        }

        private void ChangeFontSize(int fontSize)
        {
            this.Font = new Font("Segoe UI", fontSize, FontStyle.Regular);
            UpdateControlsFontRecursive(this, this.Font);
        }

        private void UpdateControlsFontRecursive(Control parent, Font newFont)
        {
            foreach (Control control in parent.Controls)
            {
                control.Font = new Font(newFont.FontFamily, newFont.Size, control.Font.Style);

                if (control.Controls.Count > 0)
                {
                    UpdateControlsFontRecursive(control, newFont);
                }
            }
        }

        private Control CreatePeopleSearchPanel()
        {
            Panel searchPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };
            TableLayoutPanel layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 2 };
            searchPanel.Controls.Add(layout);

            TextBox searchBox = new TextBox
            {
                Dock = DockStyle.Fill,
                PlaceholderText = "חיפוש לפי שם או דוא\"ל",
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 12F)
            };
            layout.Controls.Add(searchBox, 0, 0);

            Button searchButton = new Button
            {
                Text = "חפש",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold)
            };
            searchButton.Click += (sender, e) => SearchPeople(searchBox.Text);
            layout.Controls.Add(searchButton, 1, 0);

            userSearchResults = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Font = new Font("Segoe UI", 11F)
            };
            userSearchResults.Columns.Add("שם מלא", 200);
            userSearchResults.Columns.Add("תפקיד", 150);
            userSearchResults.Columns.Add("מזהה", 150);
            userSearchResults.Columns.Add("דוא\"ל", 250);
            layout.Controls.Add(userSearchResults, 0, 1);
            layout.SetColumnSpan(userSearchResults, 2);

            return searchPanel;
        }

        private void SearchPeople(string query)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(query))
                {
                    MessageBox.Show("יש להזין טקסט לחיפוש", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                List<User> allUsers = FileHandler.LoadAllUsers();

                var filteredUsers = allUsers.Where(u =>
                    u.Name.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    u.FamilyName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    u.EmailAddress.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                    u.PersonalId.Contains(query)
                ).ToList();

                userSearchResults?.Items.Clear();

                foreach (var user in filteredUsers)
                {
                    userSearchResults?.Items.Add(new ListViewItem(new[] {
                        $"{user.Name} {user.FamilyName}",
                        GetRoleDisplayName(user.Role),
                        user.PersonalId,
                        user.EmailAddress
                    }));
                }

                if (filteredUsers.Count == 0)
                {
                    MessageBox.Show("לא נמצאו תוצאות", "הודעת מערכת", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה בחיפוש: {ex.Message}", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FileHandler.LogAction($"שגיאה בחיפוש משתמשים: {ex.Message}");
            }
        }

        private Control CreateFunctionalityPanel()
        {
            Panel functionalityPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            switch (currentUser.Role)
            {
                case UserType.Student:
                    CreateStudentFunctionalityPanel(functionalityPanel);
                    break;
                case UserType.Teaching:
                    CreateTeachingFunctionalityPanel(functionalityPanel);
                    break;
                case UserType.Lecturer:
                    CreateLecturerFunctionalityPanel(functionalityPanel);
                    break;
                case UserType.DepartmentHead:
                    CreateDepartmentHeadFunctionalityPanel(functionalityPanel);
                    break;
                default:
                    Label defaultLabel = new Label
                    {
                        Text = "אין פונקציות זמינות לסוג משתמש זה",
                        Dock = DockStyle.Fill,
                        Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                        TextAlign = ContentAlignment.MiddleCenter,
                        ForeColor = Color.FromArgb(40, 50, 70)
                    };
                    functionalityPanel.Controls.Add(defaultLabel);
                    break;
            }

            return functionalityPanel;
        }

        private void CreateStudentFunctionalityPanel(Panel panel)
        {
            Label welcomeLabel = new Label
            {
                Text = $"ברוך הבא, {currentUser.Name}",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                Height = 50,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            panel.Controls.Add(welcomeLabel);

            FlowLayoutPanel buttonsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };
            panel.Controls.Add(buttonsPanel);

            AddFunctionButton(buttonsPanel, "צפייה במערכת שעות", () => ShowStudentSchedule());
            AddFunctionButton(buttonsPanel, "רישום לקורסים", () => RegisterForCourses());
            AddFunctionButton(buttonsPanel, "צפייה בציונים", () => ViewGrades());
            AddFunctionButton(buttonsPanel, "ערעור על ציון", () => AppealGrade());
            AddFunctionButton(buttonsPanel, "בקשות מיוחדות", () => SpecialRequests());
        }

        private void CreateTeachingFunctionalityPanel(Panel panel)
        {
            Label welcomeLabel = new Label
            {
                Text = $"ברוך הבא, {currentUser.Name}",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                Height = 50,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            panel.Controls.Add(welcomeLabel);

            FlowLayoutPanel buttonsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };
            panel.Controls.Add(buttonsPanel);

            AddFunctionButton(buttonsPanel, "צפייה ברשימת תלמידים", () => ViewStudentsList());
            AddFunctionButton(buttonsPanel, "הזנת ציונים", () => EnterGrades());
            AddFunctionButton(buttonsPanel, "ניהול נוכחות", () => ManageAttendance());
            AddFunctionButton(buttonsPanel, "טיפול בפניות תלמידים", () => HandleStudentInquiries());
        }

        private void CreateLecturerFunctionalityPanel(Panel panel)
        {
            Label welcomeLabel = new Label
            {
                Text = $"ברוך הבא, {currentUser.Name}",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                Height = 50,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            panel.Controls.Add(welcomeLabel);

            FlowLayoutPanel buttonsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };
            panel.Controls.Add(buttonsPanel);

            AddFunctionButton(buttonsPanel, "ניהול קורסים", () => ManageCourses());
            AddFunctionButton(buttonsPanel, "אישור ציונים", () => ApproveGrades());
            AddFunctionButton(buttonsPanel, "העלאת חומרי לימוד", () => UploadCourseMaterials());
            AddFunctionButton(buttonsPanel, "תיאום מפגשים", () => ScheduleMeetings());
            AddFunctionButton(buttonsPanel, "טיפול בערעורים", () => HandleAppeals());
        }

        private void CreateDepartmentHeadFunctionalityPanel(Panel panel)
        {
            Label welcomeLabel = new Label
            {
                Text = $"ברוך הבא, {currentUser.Name}",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                Height = 50,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(40, 50, 70)
            };
            panel.Controls.Add(welcomeLabel);

            FlowLayoutPanel buttonsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true
            };
            panel.Controls.Add(buttonsPanel);

            AddFunctionButton(buttonsPanel, "ניהול צוות אקדמי", () => ManageAcademicStaff());
            AddFunctionButton(buttonsPanel, "אישור תכניות לימודים", () => ApproveCurriculums());
            AddFunctionButton(buttonsPanel, "ניתוח נתונים אקדמיים", () => AnalyzeAcademicData());
            AddFunctionButton(buttonsPanel, "טיפול בבקשות חריגות", () => HandleSpecialRequests());
            AddFunctionButton(buttonsPanel, "ניהול תקציב מחלקה", () => ManageDepartmentBudget());
        }

        private void ShowStudentSchedule() => MessageBox.Show("מערכת שעות אישית", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void RegisterForCourses() => MessageBox.Show("רישום לקורסים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ViewGrades() => MessageBox.Show("צפייה בציונים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void AppealGrade() => MessageBox.Show("ערעור על ציון", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void SpecialRequests() => MessageBox.Show("בקשות מיוחדות", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ViewStudentsList() => MessageBox.Show("רשימת תלמידים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void EnterGrades() => MessageBox.Show("הזנת ציונים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ManageAttendance() => MessageBox.Show("ניהול נוכחות", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void HandleStudentInquiries() => MessageBox.Show("טיפול בפניות תלמידים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ManageCourses() => MessageBox.Show("ניהול קורסים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ApproveGrades() => MessageBox.Show("אישור ציונים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void UploadCourseMaterials() => MessageBox.Show("העלאת חומרי לימוד", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ScheduleMeetings() => MessageBox.Show("תיאום מפגשים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void HandleAppeals() => MessageBox.Show("טיפול בערעורים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ManageAcademicStaff() => MessageBox.Show("ניהול צוות אקדמי", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ApproveCurriculums() => MessageBox.Show("אישור תכניות לימודים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void AnalyzeAcademicData() => MessageBox.Show("ניתוח נתונים אקדמיים", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void HandleSpecialRequests() => MessageBox.Show("טיפול בבקשות חריגות", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);
        private void ManageDepartmentBudget() => MessageBox.Show("ניהול תקציב מחלקה", "פונקציונליות בפיתוח", MessageBoxButtons.OK, MessageBoxIcon.Information);

        private void AddFunctionButton(FlowLayoutPanel panel, string buttonText, Action clickAction)
        {
            Button functionButton = new Button
            {
                Text = buttonText,
                Width = 250,
                Height = 40,
                Margin = new Padding(10),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(70, 130, 180),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F),
                Cursor = Cursors.Hand
            };
            functionButton.Click += (sender, e) => clickAction();
            panel.Controls.Add(functionButton);
        }

        private Control CreateMessagesPanel()
        {
            Panel messagesPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 80F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 5F));
            messagesPanel.Controls.Add(layout);

            communicationsList = new ListView
            {
                Dock = DockStyle.Fill,
                View = View.Details,
                FullRowSelect = true,
                GridLines = true,
                Font = new Font("Segoe UI", 11F)
            };
            communicationsList.Columns.Add("תאריך", 150);
            communicationsList.Columns.Add("שולח", 150);
            communicationsList.Columns.Add("נמען", 150);
            communicationsList.Columns.Add("תוכן", 300);
            layout.Controls.Add(communicationsList, 0, 0);

            TextBox newMessageTextBox = new TextBox
            {
                Dock = DockStyle.Fill,
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 11F),
                PlaceholderText = "הקלד הודעה חדשה כאן..."
            };
            layout.Controls.Add(newMessageTextBox, 0, 1);

            Button sendButton = new Button
            {
                Text = "שלח הודעה",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            sendButton.Click += (sender, e) =>
            {
                string messageContent = newMessageTextBox.Text;
                SendNewMessage(messageContent);
                newMessageTextBox.Clear();
            };
            layout.Controls.Add(sendButton, 0, 2);

            LoadUserMessages();

            return messagesPanel;
        }

        private void SendNewMessage(string content)
        {
            if (string.IsNullOrWhiteSpace(content))
            {
                MessageBox.Show("לא ניתן לשלוח הודעה ריקה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string recipient = "recipient@example.com";

                bool success = FileHandler.StoreMessage(currentUser.EmailAddress, recipient, content);

                if (success)
                {
                    MessageBox.Show("ההודעה נשלחה בהצלחה", "הודעת מערכת", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadUserMessages();
                }
                else
                {
                    MessageBox.Show("אירעה שגיאה בשליחת ההודעה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה: {ex.Message}", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FileHandler.LogAction($"שגיאה בשליחת הודעה: {ex.Message}");
            }
        }

        private void LoadUserMessages()
        {
            try
            {
                communicationsList?.Items.Clear();

                List<Message> userMessages = FileHandler.GetUserMessages(currentUser.EmailAddress);

                foreach (var message in userMessages)
                {
                    ListViewItem item = new ListViewItem(new[] {
                        message.SentTime.ToString("dd/MM/yyyy HH:mm"),
                        message.From,
                        message.To,
                        message.Body
                    });

                    if (message.From == currentUser.EmailAddress)
                    {
                        item.BackColor = Color.FromArgb(230, 240, 250);
                    }

                    communicationsList?.Items.Add(item);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה בטעינת ההודעות: {ex.Message}", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FileHandler.LogAction($"שגיאה בטעינת הודעות: {ex.Message}");
            }
        }

        private Panel CreateHeaderPanel()
        {
            Panel headerPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(50, 120, 180) // כחול כהה
            };

            Label userInfoLabel = new Label
            {
                Text = currentUser != null
                ? $"שלום, {currentUser.Name} {currentUser.FamilyName} | {GetRoleDisplayName(currentUser.Role)}"
                : "שלום, אורח",
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Dock = DockStyle.Left,
                Padding = new Padding(10, 0, 0, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoSize = true
            };
            headerPanel.Controls.Add(userInfoLabel);

            Button logoutButton = new Button
            {
                Text = "התנתק",
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                BackColor = Color.FromArgb(200, 60, 60), // אדום
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Dock = DockStyle.Right,
                Width = 100,
                Cursor = Cursors.Hand
            };
            logoutButton.Click += LogoutUser;
            headerPanel.Controls.Add(logoutButton);

            return headerPanel;
        }

        private TabControl CreateMainTabController()
        {
            return new TabControl
            {
                Dock = DockStyle.Fill,
                Appearance = TabAppearance.FlatButtons,
                ItemSize = new Size(0, 30),
                Font = new Font("Segoe UI", 11F, FontStyle.Regular),
                ForeColor = Color.FromArgb(40, 50, 70) // כחול כהה
            };
        }

        private TabPage CreateTabView(string title, Control content)
        {
            TabPage tabView = new TabPage(title)
            {
                BackColor = Color.FromArgb(240, 245, 250), // כחול בהיר
                Padding = new Padding(10)
            };
            tabView.Controls.Add(content);
            return tabView;
        }

        private Control CreateProfilePanel()
        {
            Panel profilePanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };
            TableLayoutPanel infoLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 8 
            };
            profilePanel.Controls.Add(infoLayout);

            PictureBox profileImage = new PictureBox
            {
                Size = new Size(200, 200),
                SizeMode = PictureBoxSizeMode.Zoom,
                Dock = DockStyle.Fill,
                BorderStyle = BorderStyle.FixedSingle
            };

            if (currentUser != null && !string.IsNullOrEmpty(currentUser.Avatar) && File.Exists(currentUser.Avatar))
            {
                try
                {
                    profileImage.Image = Image.FromFile(currentUser.Avatar);
                }
                catch (Exception ex)
                {
                    FileHandler.LogAction($"שגיאה בטעינת תמונת פרופיל: {ex.Message}");
                    profileImage.Image = null;
                }
            }
            else
            {
                profileImage.BackColor = Color.LightGray;
            }

            infoLayout.Controls.Add(profileImage, 0, 0);
            infoLayout.SetColumnSpan(profileImage, 2);

            Button changeImageButton = new Button
            {
                Text = "החלף תמונה",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(70, 130, 180), // כחול בינוני
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10F),
                Cursor = Cursors.Hand
            };
            changeImageButton.Click += (sender, e) => UpdateProfileImage();
            infoLayout.Controls.Add(changeImageButton, 0, 1);
            infoLayout.SetColumnSpan(changeImageButton, 2);

            TextBox nameTextBox = new TextBox { Text = currentUser?.Name ?? "לא זמין", Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle };
            TextBox familyNameTextBox = new TextBox { Text = currentUser?.FamilyName ?? "לא זמין", Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle };
            TextBox emailTextBox = new TextBox { Text = currentUser?.EmailAddress ?? "לא זמין", Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle };
            TextBox idTextBox = new TextBox { Text = currentUser?.PersonalId ?? "לא זמין", Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle };

            AddInfoRow(infoLayout, "שם פרטי:", nameTextBox, 2);
            AddInfoRow(infoLayout, "שם משפחה:", familyNameTextBox, 3);
            AddInfoRow(infoLayout, "כתובת דוא\"ל:", emailTextBox, 4);
            AddInfoRow(infoLayout, "מספר זיהוי:", idTextBox, 5);

            Label userTypeLabel = new Label
            {
                Text = GetRoleDisplayName(currentUser?.Role ?? UserType.Student),
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 11F),
                BackColor = Color.FromArgb(240, 240, 240),
                Padding = new Padding(5),
                BorderStyle = BorderStyle.FixedSingle
            };
            AddInfoRow(infoLayout, "תפקיד:", userTypeLabel, 6);

            Button saveButton = new Button
            {
                Text = "שמור שינויים",
                Dock = DockStyle.Fill,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 120, 180), // כחול כהה
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            saveButton.Click += (sender, e) => SaveUserProfileChanges(nameTextBox.Text, familyNameTextBox.Text, emailTextBox.Text, idTextBox.Text);
            infoLayout.Controls.Add(saveButton, 0, 7);
            infoLayout.SetColumnSpan(saveButton, 2);

            return profilePanel;
        }

        private void UpdateProfileImage()
        {
            try
            {
                using (OpenFileDialog imageDialog = new OpenFileDialog())
                {
                    imageDialog.Filter = "קבצי תמונה|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
                    imageDialog.Title = "בחר תמונת פרופיל";

                    if (imageDialog.ShowDialog() == DialogResult.OK)
                    {
                        string selectedImagePath = imageDialog.FileName;

                        currentUser.Avatar = selectedImagePath;

                        bool updateSuccess = FileHandler.UpdateUserDetails(currentUser);

                        if (updateSuccess)
                        {
                            MessageBox.Show("תמונת הפרופיל עודכנה בהצלחה", "הודעת מערכת", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            SetupModernInterface();
                        }
                        else
                        {
                            MessageBox.Show("אירעה שגיאה בעדכון תמונת הפרופיל", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה: {ex.Message}", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FileHandler.LogAction($"שגיאה בעדכון תמונת פרופיל: {ex.Message}");
            }
        }

        private void SaveUserProfileChanges(string name, string familyName, string email, string id)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(familyName) || string.IsNullOrWhiteSpace(email))
                {
                    MessageBox.Show("שדות השם, שם המשפחה והדוא\"ל הם שדות חובה", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                currentUser.Name = name;
                currentUser.FamilyName = familyName;
                currentUser.EmailAddress = email;
                currentUser.PersonalId = id;

                bool updateSuccess = FileHandler.UpdateUserDetails(currentUser);

                if (updateSuccess)
                {
                    MessageBox.Show("הפרטים עודכנו בהצלחה", "הודעת מערכת", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    SetupModernInterface();
                }
                else
                {
                    MessageBox.Show("אירעה שגיאה בעדכון הפרטים", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה: {ex.Message}", "שגיאה", MessageBoxButtons.OK, MessageBoxIcon.Error);
                FileHandler.LogAction($"שגיאה בעדכון פרטי משתמש: {ex.Message}");
            }
        }

        private void AddInfoRow(TableLayoutPanel layout, string label, Control valueControl, int row)
        {
            Label labelControl = new Label
            {
                Text = label,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                ForeColor = Color.FromArgb(40, 50, 70) // כחול כהה
            };
            layout.Controls.Add(labelControl, 0, row);
            layout.Controls.Add(valueControl, 1, row);
        }

        private string GetRoleDisplayName(UserType role)
        {
            switch (role)
            {
                case UserType.Student:
                    return "סטודנט";
                case UserType.Teaching:
                    return "מתרגל";
                case UserType.Lecturer:
                    return "מרצה";
                case UserType.DepartmentHead:
                    return "ראש מחלקה";
                default:
                    return "משתמש";
            }
        }

        private void LogoutUser(object? sender, EventArgs e)
        {
            if (MessageBox.Show("האם אתה בטוח שברצונך להתנתק?", "אישור התנתקות", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                FileHandler.LogAction($"משתמש התנתק: {currentUser.EmailAddress}");
                this.Close();
                loginForm.Show();
            }
        }
    }
}