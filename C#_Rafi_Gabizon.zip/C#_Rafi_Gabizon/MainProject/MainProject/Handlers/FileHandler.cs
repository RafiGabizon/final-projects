using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MainProject.Classes;
using MainProject.Enums;

namespace MainProject
{
    /// <summary>
    /// מחלקה סטטית לטיפול בקריאה וכתיבה של קבצים
    /// </summary>
    public static class FileHandler
    {
        // שינוי שמות קבצים
        private const string USER_DATA_FILE = "university_users.txt";
        private const string MESSAGE_DATA_FILE = "university_messages.txt";
        private const string LOG_FILE = "app_log.txt"; // קובץ חדש ללוגים

        /// <summary>
        /// טוען את כל המשתמשים מהקובץ
        /// </summary>
        public static List<User> LoadAllUsers()
        {
            List<User> usersList = new List<User>();

            try
            {
                // שימוש בנתיב מלא כולל התיקייה הנוכחית
                string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, USER_DATA_FILE);
                LogAction($"ניסיון טעינת משתמשים מהקובץ: {fullPath}");

                if (!File.Exists(fullPath))
                {
                    LogAction($"קובץ המשתמשים לא נמצא: {fullPath}");
                    return usersList;
                }

                string[] userRecords = File.ReadAllLines(fullPath);
                LogAction($"נטענו {userRecords.Length} רשומות משתמשים");

                foreach (string record in userRecords)
                {
                    // פיצול הרשומה לפי פסיקים
                    string[] userData = record.Split(',');

                    // בדיקה שיש מספיק שדות
                    if (userData.Length < 6)
                    {
                        LogAction($"רשומת משתמש לא תקינה: {record}");
                        continue;
                    }

                    // המרת סוג המשתמש
                    if (!Enum.TryParse(userData[4], out UserType role))
                    {
                        LogAction($"סוג משתמש לא מוכר: {userData[4]}");
                        continue;
                    }

                    // יצירת משתמש בהתאם לסוג
                    User newUser = CreateUserByType(userData, role);
                    if (newUser != null)
                    {
                        usersList.Add(newUser);
                    }
                }

                LogAction($"נטענו בהצלחה {usersList.Count} משתמשים");
            }
            catch (Exception ex)
            {
                LogAction($"שגיאה בטעינת משתמשים: {ex.Message}");
            }

            return usersList;
        }

        /// <summary>
        /// יוצר משתמש מתאים בהתאם לסוג
        /// </summary>
        private static User CreateUserByType(string[] userData, UserType role)
        {
            try
            {
                switch (role)
                {
                    case UserType.Student:
                        return new Student
                        {
                            Name = userData[0],
                            FamilyName = userData[1],
                            EmailAddress = userData[2],
                            PersonalId = userData[5],
                            StudentId = userData[5],
                            Role = role,
                            Avatar = userData.Length > 6 ? userData[6] : null,
                            RegisterDate = DateTime.Now
                        };

                    case UserType.Teaching:
                    case UserType.Lecturer:
                    case UserType.DepartmentHead:
                        return new Teacher
                        {
                            Name = userData[0],
                            FamilyName = userData[1],
                            EmailAddress = userData[2],
                            PersonalId = userData[5],
                            StaffId = userData[5],
                            Role = role,
                            Avatar = userData.Length > 6 ? userData[6] : null,
                            RegisterDate = DateTime.Now
                        };

                    default:
                        return new User
                        {
                            Name = userData[0],
                            FamilyName = userData[1],
                            EmailAddress = userData[2],
                            PersonalId = userData[5],
                            Role = role,
                            Avatar = userData.Length > 6 ? userData[6] : null,
                            RegisterDate = DateTime.Now
                        };
                }
            }
            catch (Exception ex)
            {
                LogAction($"שגיאה ביצירת משתמש: {ex.Message}");
                throw new InvalidOperationException("Failed to create user due to invalid data.");
            }
        }

        /// <summary>
        /// שומר הודעה חדשה בקובץ
        /// </summary>
        public static bool StoreMessage(string sender, string recipient, string content)
        {
            try
            {
                string messageRecord = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss},{sender},{recipient},{content}";
                File.AppendAllText(MESSAGE_DATA_FILE, messageRecord + Environment.NewLine);
                LogAction($"הודעה נשמרה בהצלחה: מאת {sender} אל {recipient}");
                return true;
            }
            catch (Exception ex)
            {
                LogAction($"שגיאה בשמירת הודעה: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// טוען את כל ההודעות של משתמש מסוים
        /// </summary>
        public static List<Message> GetUserMessages(string userEmail)
        {
            List<Message> messagesList = new List<Message>();

            try
            {
                if (!File.Exists(MESSAGE_DATA_FILE))
                {
                    LogAction($"קובץ ההודעות לא קיים: {MESSAGE_DATA_FILE}");
                    return messagesList;
                }

                string[] messageRecords = File.ReadAllLines(MESSAGE_DATA_FILE);

                foreach (string record in messageRecords)
                {
                    string[] parts = record.Split(',');

                    // בדיקה שיש לפחות 4 שדות: תאריך, שולח, נמען, תוכן
                    if (parts.Length < 4)
                    {
                        continue;
                    }

                    // בדיקה שההודעה קשורה למשתמש
                    if (parts[1] == userEmail || parts[2] == userEmail)
                    {
                        try
                        {
                            DateTime messageTime = DateTime.Parse(parts[0]);
                            Message msg = new Message(parts[1], parts[2], JoinRemainingParts(parts, 3), messageTime);
                            messagesList.Add(msg);
                        }
                        catch (Exception ex)
                        {
                            LogAction($"שגיאה בפענוח הודעה: {ex.Message}");
                        }
                    }
                }

                // מיון ההודעות לפי תאריך
                messagesList = messagesList.OrderByDescending(m => m.SentTime).ToList();
                LogAction($"נטענו {messagesList.Count} הודעות עבור {userEmail}");
            }
            catch (Exception ex)
            {
                LogAction($"שגיאה בטעינת הודעות: {ex.Message}");
            }

            return messagesList;
        }

        /// <summary>
        /// מאחד את כל החלקים הנותרים של פיצול המחרוזת (שימושי אם תוכן ההודעה מכיל פסיקים)
        /// </summary>
        private static string JoinRemainingParts(string[] parts, int startIndex)
        {
            if (startIndex >= parts.Length)
            {
                return string.Empty;
            }

            return string.Join(",", parts.Skip(startIndex));
        }

        /// <summary>
        /// שומר לוג של פעולה במערכת
        /// </summary>
        public static void LogAction(string action)
        {
            try
            {
                string logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {action}";
                File.AppendAllText(LOG_FILE, logEntry + Environment.NewLine);
            }
            catch
            {
                // התעלם משגיאות ברישום לוג
            }
        }

        /// <summary>
        /// מעדכן פרטי משתמש בקובץ
        /// </summary>
        public static bool UpdateUserDetails(User user)
        {
            try
            {
                if (!File.Exists(USER_DATA_FILE))
                {
                    LogAction("קובץ משתמשים לא קיים, לא ניתן לעדכן");
                    return false;
                }

                List<string> allLines = File.ReadAllLines(USER_DATA_FILE).ToList();
                bool userFound = false;

                for (int i = 0; i < allLines.Count; i++)
                {
                    string[] parts = allLines[i].Split(',');

                    if (parts.Length >= 3 && parts[2] == user.EmailAddress)
                    {
                        string userType = DetermineUserTypeString(user.Role);
                        string avatarPath = user.Avatar ?? "";

                        // בניית רשומת המשתמש המעודכנת
                        string updatedRecord = $"{user.Name},{user.FamilyName},{user.EmailAddress},password,{userType},{user.PersonalId},{avatarPath}";
                        allLines[i] = updatedRecord;
                        userFound = true;
                        break;
                    }
                }

                if (userFound)
                {
                    File.WriteAllLines(USER_DATA_FILE, allLines);
                    LogAction($"פרטי המשתמש {user.EmailAddress} עודכנו בהצלחה");
                    return true;
                }
                else
                {
                    LogAction($"המשתמש {user.EmailAddress} לא נמצא, לא בוצע עדכון");
                    return false;
                }
            }
            catch (Exception ex)
            {
                LogAction($"שגיאה בעדכון פרטי משתמש: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// המרת סוג משתמש למחרוזת בעברית
        /// </summary>
        private static string DetermineUserTypeString(UserType userType)
        {
            switch (userType)
            {
                case UserType.Student:
                    return "סטודנט";
                case UserType.Teaching:
                    return "מתרגל";
                case UserType.Lecturer:
                    return "מרצה";
                case UserType.DepartmentHead:
                    return "ראש מחלקה";
                default:
                    return "משתמש";
            }
        }
    }
}