using System;
using System.Windows.Forms;

namespace MainProject
{

    internal static class Program
    {

        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                FileHandler.LogAction("מערכת המידע האקדמית הופעלה");

                Application.Run(new Form1());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"אירעה שגיאה בהפעלת המערכת: {ex.Message}",
                    "שגיאת מערכת",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                FileHandler.LogAction($"שגיאה קריטית בהפעלת המערכת: {ex.Message}");
            }
        }
    }
}