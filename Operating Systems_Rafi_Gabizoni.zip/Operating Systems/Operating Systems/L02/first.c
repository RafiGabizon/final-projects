#include <stdio.h>

int calculate_factorial(int num);
int find_maximum(int num1, int num2);
int calculate_sum(int num);
int calculate_power(int base, int exponent);

int main()
{

    int result = calculate_factorial(10);
    printf("Factorial of 10: %d\n", result);

    result = calculate_sum(10);
    printf("Sum from 0 to 10: %d\n", result);

    result = find_maximum(10, 7);
    printf("Maximum between 10 and 7: %d\n", result);

    result = calculate_power(10, 5);
    printf("10 raised to power 5: %d\n", result);

    return 0;
}

int calculate_factorial(int num)
{
    int result = 1;
    for (int i = 2; i <= num; i++)
    {
        result = result * i;
    }
    return result;
}

int find_maximum(int num1, int num2)
{
    return (num1 > num2) ? num1 : num2;
}

int calculate_sum(int num)
{
    int total = 0;
    int i = 0;
    while (i <= num)
    {
        total += i;
        i++;
    }
    return total;
}

int calculate_power(int base, int exponent)
{
    int result = 1;
    int count = 0;
    while (count < exponent)
    {
        result *= base;
        count++;
    }
    return result;
}