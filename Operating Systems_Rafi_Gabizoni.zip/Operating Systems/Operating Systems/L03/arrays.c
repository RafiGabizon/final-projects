#include <stdio.h>

int main()
{
    int numbers[10];
    numbers[0] = 0;
    numbers[1] = 0;
    numbers[2] = 0;
    printf("--------numbers----------\n");
    for (int i = 0; i < 10; i++)
    {
        printf("%d\n", numbers[i]);
    }
    printf("---------------------\n");

    printf("--------numbers2----------\n");
    int numbers2[10] = {1, 2, 3, 4, 5};
    for (int i = 0; i < 10; i++)
    {
        printf("%d\n", numbers2[i]);
    }
    printf("---------------------\n");

    printf("--------numbers3----------\n");
    int numbers3[] = {1, 2, 3, 4, 5};
    for (int i = 0; i < sizeof(numbers3) / sizeof(int); i++)
    {
        printf("%d\n", numbers3[i]);
    }
    printf("---------------------\n");

    printf("sizeof int %ld\n", sizeof(int));
    printf("sizeof double %ld\n", sizeof(double));
    printf("sizeof float %ld\n", sizeof(float));
    printf("sizeof char %ld\n", sizeof(char));

    printf("sizeof numbers[] %ld\n", sizeof(numbers));
    printf("sizeof address %ld\n", sizeof((numbers + 1)));

    printf("%p\n", numbers);
    printf("%p\n", numbers + 1);

    printf("Enter number\n");

    int value = 4;
    printf("%d\n", value);
    printf("%p\n", &value);

    printf("------------------------------\n");
    printf("%p\n", numbers);
    printf("------------------------------\n");

    scanf("%d", &value);

    printf("%d\n", value);
    printf("%p\n", &value);

    for (int i = 0; i < 10; i++)
    {
        scanf("%d", numbers + i);
        scanf("%d", &numbers[i]);
    }

    return 0;
}