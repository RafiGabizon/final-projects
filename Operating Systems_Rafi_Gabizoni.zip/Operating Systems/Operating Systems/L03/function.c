#include <stdio.h>

int display(int val1, int val2);

int main()
{
    float result = display(7, 5);
    printf("%lf", display(7, 5));
    printf("Hello World\n");

    return 0;
}

int display(int val1, int val2)
{
    printf("%d\n", val1);
    printf("%d \n", val1);
    printf(" %d \n", val1);
    printf(" %d%d \n", val1, val2);
    printf(" %d %d \n", val1, val2);

    printf(" %d %d \n", val1 * 10, val2 * 15);
    printf(" %i %i \n", val1 * 10, val2 * 15);
    printf(" %c %c \n", val1 * 10, val2 * 15);

    printf(" %s \n", "Hello Edi");

    printf("display\n");

    return 1;
}