#include <stdio.h>

int main()
{
    char letter = 'a';
    char characters[] = {'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b', 'a', 'b'};
    printf("--------------------------------\n");
    for (int i = 0; i < 8; i++)
    {
        printf("%d -> %c \n", characters[i], characters[i]);
    }
    printf("-----------------while---------------\n");
    int i = 0;
    while (characters[i])
    {
        printf("%d -> %c \n", characters[i], characters[i]);
        i++;
    }
    printf("---------------end while-----------------\n");

    printf("-----------------while---------------\n");
    i++;
    while (characters[i])
    {
        printf("%d -> %c \n", characters[i], characters[i]);
        i++;
    }
    printf("---------------end while-----------------\n");

    char text[] = "abcd";
    for (int i = 0; i < 5; i++)
    {
        printf("%d -> %c \n", text[i], text[i]);
    }
    char word[5];
    word[0] = 'a';
    word[1] = 'b';
    word[2] = 'c';
    word[3] = 'd';
    word[4] = '\0';

    return 0;
}