#include "myFunction.h"

// פונקציה להצגת מיקום נוכחי
void displayCurrentLocation()
{
    char currentPath[SIZE_BUFF];
    char systemName[SIZE_BUFF];
    char *currentUser;

    currentUser = getenv("USER"); // קבלת שם המשתמש
    if (currentUser == NULL)      // בדיקת תקינות שם המשתמש
        printf("Failed to get username\n");
    else
    {
        if (getcwd(currentPath, SIZE_BUFF) == NULL) // קבלת נתיב נוכחי
            printf("Failed to get current path\n");
        else
        {
            if (gethostname(systemName, SIZE_BUFF) == -1) // קבלת שם מערכת
                printf("Failed to get hostname\n");
            else
            {
                printf("\033[1;34m%s@%s\033[0m:\033[0;32m%s\033[0m$ ", currentUser, systemName, currentPath); // הדפסת פרטי המיקום
                fflush(stdout);
            }
        }
    }
}

// פונקציה לקליטת פקודה מהמשתמש
char *readCommand()
{
    char currentChar;
    int bufferSize = 1;
    int position = 0;
    char *inputBuffer = (char *)malloc(bufferSize * sizeof(char)); // הקצאת זיכרון ראשונית

    if (inputBuffer == NULL)
    {
        perror("Memory allocation failed");
        exit(EXIT_FAILURE);
    }

    while ((currentChar = getchar()) != '\n') // קריאת תווים עד סוף שורה
    {
        inputBuffer[position] = currentChar; // שמירת התו הנוכחי
        position++;
        bufferSize++;

        char *tempBuffer = (char *)realloc(inputBuffer, bufferSize); // הגדלת הזיכרון לפי הצורך
        if (tempBuffer == NULL)
        {
            free(inputBuffer);
            perror("Memory reallocation failed");
            exit(EXIT_FAILURE);
        }
        inputBuffer = tempBuffer;
    }

    inputBuffer[position] = '\0'; // הוספת תו סיום מחרוזת
    return inputBuffer;
}

// פונקציה לפיצול פקודה לארגומנטים
char **parseCommand(char *commandLine)
{
    int arraySize = 2; // גודל התחלתי של מערך הארגומנטים
    int argIndex = 0;
    char *token = commandLine;                                 // מצביע לתחילת המחרוזת
    char *nextToken;                                           // מצביע לתו הבא
    char **args = (char **)malloc(arraySize * sizeof(char *)); // הקצאת זיכרון למערך ארגומנטים

    if (args == NULL)
    { // בדיקת תקינות ההקצאה
        perror("Failed to allocate memory");
        exit(EXIT_FAILURE);
    }

    // דילוג על רווחים בתחילת הפקודה
    while (*token == ' ')
    {
        token++;
    }

    while (*token != '\0')
    { // עיבוד המחרוזת עד לסופה
        if (*token == '"')
        {                                       // טיפול במחרוזת בתוך מרכאות
            nextToken = strchr(token + 1, '"'); // חיפוש סגירת מרכאות
            if (nextToken == NULL)
            {
                perror("Missing closing quote");
                errno = EINVAL;
                break;
            }
            token++;           // דילוג על מרכאות פתיחה
            *nextToken = '\0'; // החלפת מרכאות סגירה בתו סיום

            if (*(nextToken + 1) == ' ')
            {
                nextToken += 2; // קידום לאחר הרווח
            }
            else if (*(nextToken + 1) != '\0')
            {
                perror("Expected space after closing quote");
                errno = EINVAL;
                break;
            }
            else
            {
                nextToken++;
            }
        }
        else
        {
            nextToken = strchr(token, ' '); // חיפוש הרווח הבא
            if (nextToken != NULL)
            {
                *nextToken = '\0'; // הפיכת הרווח לתו סיום
                nextToken++;
            }
            else
            {
                nextToken = token + strlen(token); // הצבעה לסוף המחרוזת
            }
        }

        args[argIndex] = token; // שמירת הארגומנט הנוכחי במערך
        argIndex++;

        if (argIndex >= arraySize)
        { // הגדלת המערך במידת הצורך
            arraySize += 2;
            char **tempArgs = (char **)realloc(args, arraySize * sizeof(char *));
            if (tempArgs == NULL)
            {
                free(args);
                perror("Failed to reallocate memory");
                exit(EXIT_FAILURE);
            }
            args = tempArgs;
        }

        args[argIndex] = NULL; // סימון סוף המערך
        token = nextToken;     // מעבר לתו הבא

        // דילוג על רווחים מיותרים
        while (*token == ' ')
        {
            token++;
        }
    }

    return args;
}

// פונקציה ליציאה מהמעטפת
void exitShell(char *command)
{
    free(command);
    puts("logout");
    exit(EXIT_SUCCESS);
}

// פונקציה להדפסת ארגומנטים
void printArguments(char **args)
{
    int i = 1;
    while (args[i] != NULL)
    {
        printf("%s ", args[i]);
        i++;
    }
    printf("\n");
}

// פונקציה לשינוי תיקייה נוכחית
void changeDirectory(char **dirPath)
{
    if (dirPath[2] != NULL)
    { // בדיקת מספר ארגומנטים
        printf("-myShell: cd: too many arguments\n");
        return;
    }

    if (chdir(dirPath[1]) != 0) // ביצוע שינוי תיקייה
        printf("-myShell: cd: %s: No such file or directory\n", dirPath[1]);
}

// פונקציה להעתקת קבצים
void copyFile(char **args)
{
    // בדיקת תקינות ארגומנטים
    if (args[1] == NULL || args[2] == NULL)
    {
        puts("Error: Missing source or destination file");
        return;
    }

    if (args[3] != NULL)
    {
        puts("Error: Too many arguments for cp command");
        return;
    }

    FILE *sourceFile, *destFile;
    int ch;

    // פתיחת קובץ מקור לקריאה
    sourceFile = fopen(args[1], "r");
    if (sourceFile == NULL)
    {
        puts("Error: Cannot open source file");
        return;
    }

    // פתיחת קובץ יעד לכתיבה
    destFile = fopen(args[2], "w");
    if (destFile == NULL)
    {
        puts("Error: Cannot open destination file");
        fclose(sourceFile);
        return;
    }

    // העתקת תוכן מקובץ לקובץ
    while ((ch = fgetc(sourceFile)) != EOF)
        fputc(ch, destFile);

    fclose(sourceFile);
    fclose(destFile);
}

// פונקציה להצגת תוכן תיקייה נוכחית
void listDirectory()
{
    DIR *directory;
    struct dirent *entry;

    directory = opendir("./");
    if (directory == NULL)
    {
        perror("Cannot open directory");
        return;
    }

    while ((entry = readdir(directory)) != NULL)
        printf("%s ", entry->d_name);

    printf("\n");
    closedir(directory);
}

// פונקציה למחיקת קובץ
void removeFile(char **filePath)
{
    if (unlink(filePath[1]) != 0)
        printf("-myShell: delete: %s: No such file or directory\n", filePath[1]);
}

// פונקציה להפעלת תוכניות חיצוניות
void executeExternalCommand(char **cmdArgs)
{
    pid_t childPid = fork(); // יצירת תהליך משנה

    if (childPid < 0)
    {
        perror("Fork operation failed");
        return;
    }

    if (childPid == 0)
    { // קוד לתהליך הילד
        if (execvp(cmdArgs[0], cmdArgs) == -1)
        {
            perror("Command execution failed");
            exit(EXIT_FAILURE);
        }
    }
    else
    {
        // תהליך האב מחכה לסיום הילד
        int status;
        waitpid(childPid, &status, 0);
    }
}

// פונקציה להעברת קבצים ממיקום למיקום
void moveFile(char **fileArgs)
{
    if (rename(fileArgs[1], fileArgs[2]) != 0)
    {
        perror("File move operation failed");
    }
}

// פונקציה להוספת תוכן לקובץ קיים
void appendToFile(char **contentArgs)
{
    FILE *outputFile;

    outputFile = fopen(contentArgs[2], "a");
    if (outputFile == NULL)
    {
        perror("Cannot open output file");
        return;
    }

    fprintf(outputFile, "%s", contentArgs[1]);
    fclose(outputFile);
}

// פונקציה ליצירת קובץ חדש עם תוכן
void writeToFile(char **contentArgs)
{
    FILE *outputFile;

    outputFile = fopen(contentArgs[2], "w");
    if (outputFile == NULL)
    {
        perror("Cannot create output file");
        return;
    }

    fprintf(outputFile, "%s", contentArgs[1]);
    fclose(outputFile);
}

// פונקציה לקריאת תוכן קובץ
void displayFileContents(char **fileArgs)
{
    FILE *inputFile;
    int ch;

    inputFile = fopen(fileArgs[1], "r");
    if (inputFile == NULL)
    {
        perror("Cannot open input file");
        return;
    }

    while ((ch = fgetc(inputFile)) != EOF)
    {
        putchar(ch);
    }

    fclose(inputFile);
}

// פונקציה לספירת מילים או שורות בקובץ
void countFileElements(char **countArgs)
{
    FILE *inputFile;
    int ch;
    int lineCount = 0, wordCount = 0, charCount = 0;
    int inWord = 0; // דגל לסימון אם אנחנו בתוך מילה

    inputFile = fopen(countArgs[2], "r");
    if (inputFile == NULL)
    {
        perror("Cannot open file for counting");
        return;
    }

    while ((ch = fgetc(inputFile)) != EOF)
    {
        charCount++;

        if (ch == '\n')
        {
            lineCount++;
            inWord = 0;
        }

        if (ch == ' ' || ch == '\t' || ch == '\n')
        {
            inWord = 0;
        }
        else if (inWord == 0)
        {
            inWord = 1;
            wordCount++;
        }
    }

    if (countArgs[1][1] == 'l')
    {
        printf("Lines: %d\n", lineCount);
    }
    else if (countArgs[1][1] == 'w')
    {
        printf("Words: %d\n", wordCount);
    }
    else if (countArgs[1][1] == 'c')
    {
        printf("Characters: %d\n", charCount);
    }

    fclose(inputFile);
}

// פונקציה להעברת פלט בין תהליכים באמצעות צינור
void createPipe(char **command1, char **command2)
{
    int pipefd[2];
    pid_t pid1, pid2;

    if (pipe(pipefd) == -1)
    {
        perror("Pipe creation failed");
        return;
    }

    pid1 = fork();
    if (pid1 < 0)
    {
        perror("First fork failed");
        return;
    }

    if (pid1 == 0)
    {                                   // תהליך ילד ראשון
        close(pipefd[0]);               // סגירת קצה הקריאה
        dup2(pipefd[1], STDOUT_FILENO); // הפניית פלט סטנדרטי לצינור
        close(pipefd[1]);

        execvp(command1[0], command1);
        perror("First command execution failed");
        exit(EXIT_FAILURE);
    }

    pid2 = fork();
    if (pid2 < 0)
    {
        perror("Second fork failed");
        return;
    }

    if (pid2 == 0)
    {                                  // תהליך ילד שני
        close(pipefd[1]);              // סגירת קצה הכתיבה
        dup2(pipefd[0], STDIN_FILENO); // הפניית קלט סטנדרטי מהצינור
        close(pipefd[0]);

        execvp(command2[0], command2);
        perror("Second command execution failed");
        exit(EXIT_FAILURE);
    }

    // תהליך אב סוגר את שני קצוות הצינור
    close(pipefd[0]);
    close(pipefd[1]);

    // המתנה לסיום שני התהליכים
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);
}