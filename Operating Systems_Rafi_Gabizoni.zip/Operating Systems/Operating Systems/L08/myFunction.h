#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pwd.h>
#include <dirent.h>
#include <errno.h>

#define SIZE_BUFF 256

char *readCommand();

/**
 * Parses a command string into an array of arguments.
 *
 * This function takes a command string as input and breaks it into individual
 * tokens based on spaces, while preserving quoted strings as single arguments.
 * It dynamically allocates memory for the array of argument strings.
 *
 * @param commandLine A pointer to the command string to be parsed.
 *
 * @return A dynamically allocated array of strings (char**) containing the parsed
 *         arguments. The array is NULL-terminated. Returns NULL if commandLine is NULL
 *         or if memory allocation fails.
 *
 * @note The input string will be modified during parsing.
 *       If the original string needs to be preserved, pass a copy.
 *
 * @warning The caller must free the returned array and its elements
 *          when no longer needed.
 */
char **parseCommand(char *commandLine);

void displayCurrentLocation();

void exitShell(char *command);
void printArguments(char **args);
void changeDirectory(char **dirPath);
void copyFile(char **arguments);
void displayFileContents(char **args);
void writeToFile(char **args);
void countFileElements(char **args);
void appendToFile(char **args);
void moveFile(char **args);
void createPipe(char **command1, char **command2);
void executeExternalCommand(char **arguments);
void removeFile(char **path);
void listDirectory();

// Memory layout examples:
// Single string example:
// char str[10] = "hello"
// char* p = str;
// *p is equivalent to p[0]
// *(p+1) is equivalent to p[1]

// String array example:
// char matstr[6][6] = {100x={"h","e","l","l","o"}, 378x={"h","e","l","l","o"},
//                      1987x={"h","e","l","l","o"}, 649x={"h","e","l","l","o"},
//                      {"h","e","l","l","o"}, {"h","e","l","l","o"}}
// char** pp = matstr
// *(*(pp)) is equivalent to pp[0][0]
// *(*(pp+1)+2) is equivalent to pp[1][2]