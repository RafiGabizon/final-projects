#include "myShell.h"
#include "myFunction.h"

// משתנה גלובלי המציין האם התגלה צינור בפקודה
bool hasPipeOperator = false;

/**
 * פונקציה המפצלת שורת פקודה עם צינורות למערך של מערכים
 * כל מערך מכיל את הפקודה שלפני או אחרי הצינור
 */
char ***parsePipeCommands(char **commandArgs)
{
    // הקצאת זיכרון ראשונית למערך תוצאה
    char ***commandGroups = (char ***)malloc(sizeof(char **) * 1);
    if (commandGroups == NULL)
    {
        perror("Memory allocation failed");
        return NULL;
    }

    int tokenCount = 0;
    int groupIndex = 0;
    int totalArgs = 0;

    // ספירת הארגומנטים וזיהוי צינורות
    for (int i = 0; commandArgs[i]; i++)
    {
        tokenCount++;
        totalArgs++;

        if (strcmp(commandArgs[i], "|") == 0)
        {
            hasPipeOperator = true;

            // הקצאת זיכרון למערך הבא של ארגומנטים
            char ***tempGroups = (char ***)realloc(commandGroups, sizeof(char **) * (groupIndex + 2));
            if (tempGroups == NULL)
            {
                perror("Memory reallocation failed");
                free(commandGroups);
                return NULL;
            }
            commandGroups = tempGroups;

            // הקצאת זיכרון למערך הארגומנטים הנוכחי
            commandGroups[groupIndex] = (char **)malloc(sizeof(char *) * tokenCount);
            if (commandGroups[groupIndex] == NULL)
            {
                perror("Memory allocation for command group failed");
                // שחרור כל הזיכרון שהוקצה עד כה
                for (int j = 0; j < groupIndex; j++)
                {
                    free(commandGroups[j]);
                }
                free(commandGroups);
                return NULL;
            }

            // העתקת הארגומנטים למערך הנוכחי
            for (int j = i - tokenCount + 1; j < i; j++)
            {
                commandGroups[groupIndex][j - (i - tokenCount + 1)] = commandArgs[j];
            }
            commandGroups[groupIndex][tokenCount - 1] = NULL;

            groupIndex++;
            tokenCount = 0;
        }
    }

    // טיפול במקרה שיש צינור
    if (hasPipeOperator)
    {
        // הקצאת זיכרון לקבוצת הפקודה האחרונה
        char ***tempGroups = (char ***)realloc(commandGroups, sizeof(char **) * (groupIndex + 2));
        if (tempGroups == NULL)
        {
            perror("Final reallocation failed");
            // שחרור זיכרון
            for (int j = 0; j < groupIndex; j++)
            {
                free(commandGroups[j]);
            }
            free(commandGroups);
            return NULL;
        }
        commandGroups = tempGroups;

        commandGroups[groupIndex] = (char **)malloc(sizeof(char *) * (tokenCount + 1));
        if (commandGroups[groupIndex] == NULL)
        {
            perror("Memory allocation for final command group failed");
            // שחרור זיכרון
            for (int j = 0; j < groupIndex; j++)
            {
                free(commandGroups[j]);
            }
            free(commandGroups);
            return NULL;
        }

        // העתקת הארגומנטים האחרונים
        for (int j = totalArgs - tokenCount; j < totalArgs; j++)
        {
            commandGroups[groupIndex][j - (totalArgs - tokenCount)] = commandArgs[j];
        }
        commandGroups[groupIndex][tokenCount] = NULL;

        groupIndex++;
        commandGroups[groupIndex] = NULL;
    }
    else
    {
        // אם אין צינור, שחררו את הזיכרון והחזירו NULL
        free(commandGroups);
        return NULL;
    }

    return commandGroups;
}

int main()
{
    // הצגת הודעת פתיחה
    displayWelcomeMessage();

    while (1)
    {
        hasPipeOperator = false;
        errno = 0;

        // הצגת נתיב נוכחי ומחכים לפקודה
        displayCurrentLocation();
        char *inputCommand = readCommand();

        // בדיקה אם המשתמש רוצה לצאת
        if (strcmp(inputCommand, "exit") == 0 || strncmp(inputCommand, "exit ", 5) == 0)
            exitShell(inputCommand);

        // פיצול הפקודה לארגומנטים
        char **commandArgs = parseCommand(inputCommand);

        // בדיקה נוספת לפקודת יציאה
        if (strcmp(commandArgs[0], "exit") == 0)
        {
            free(commandArgs);
            exitShell(inputCommand);
        }

        // בדיקה אם יש צינורות בפקודה
        char ***pipeCommands = parsePipeCommands(commandArgs);

        // בדיקה אם התרחשה שגיאה בפיצול הפקודה
        if (errno != 0)
        {
            free(commandArgs);
            free(inputCommand);
            continue;
        }

        // ביצוע הפקודה המתאימה
        if (strcmp(commandArgs[0], "echo") == 0 && commandArgs[1] != NULL &&
            strcmp(commandArgs[1], ">") != 0 && strcmp(commandArgs[1], ">>") != 0)
            printArguments(commandArgs);
        else if (strcmp(commandArgs[0], "cd") == 0)
            changeDirectory(commandArgs);
        else if (strcmp(commandArgs[0], "cp") == 0)
            copyFile(commandArgs);
        else if (strcmp(commandArgs[0], "read") == 0)
            displayFileContents(commandArgs);
        else if (strcmp(commandArgs[0], "echo") == 0 && commandArgs[1] != NULL &&
                 commandArgs[2] != NULL && strcmp(commandArgs[2], ">") == 0)
            writeToFile(commandArgs);
        else if (strcmp(commandArgs[0], "wc") == 0)
            countFileElements(commandArgs);
        else if (strcmp(commandArgs[0], "echo") == 0 && commandArgs[1] != NULL &&
                 commandArgs[2] != NULL && strcmp(commandArgs[2], ">>") == 0)
            appendToFile(commandArgs);
        else if (strcmp(commandArgs[0], "mv") == 0)
            moveFile(commandArgs);
        else if (strcmp(commandArgs[0], "delete") == 0)
            removeFile(commandArgs);
        else if (strcmp(commandArgs[0], "dir") == 0)
            listDirectory();
        else if (hasPipeOperator)
        {
            // ביצוע פקודות עם צינור
            createPipe(pipeCommands[0], pipeCommands[1]);

            // המתנה לסיום תהליכי הילד
            wait(NULL);

            // שחרור זיכרון מערכי הפקודות
            for (int i = 0; pipeCommands[i]; i++)
            {
                free(pipeCommands[i]);
            }
            free(pipeCommands);
        }
        else
        {
            // ביצוע פקודה חיצונית
            executeExternalCommand(commandArgs);
            wait(NULL);
        }

        // שחרור זיכרון
        free(commandArgs);
        free(inputCommand);
    }

    return 0;
}

/**
 * פונקציה להצגת הודעת פתיחה למשתמש
 */
void displayWelcomeMessage()
{
    printf("Welcome to my Custom Shell\n");
    printf("GitHub Username:\n");
    printf(" _____            __ _ \n");
    printf("|  __ \\          / _(_)\n");
    printf("| |__) |__ _ ___| |_ _ \n");
    printf("|  _  // _` / __|  _| |\n");
    printf("| | \\ \\ (_| \\__ \\ | | |\n");
    printf("|_|  \\_\\__,_|___/_| |_|\n");
    printf("\n");
}