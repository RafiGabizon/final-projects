interface MeetingInterface {
    location: string;
    DataAndTime:Date;
}
export default MeetingInterface;