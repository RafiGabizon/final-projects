interface TaskInterface {
    lastDataExecution: Date;
    
}
export default TaskInterface;