import React from 'react';
import '../CSS/Stripe.css';

function Stripe() {
    return (
        <div className="stripe-container">
            Welcome To Our Companies Search Site!
        </div>
    );
}

export default Stripe;
