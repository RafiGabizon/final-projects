import EmployeeList from "../Components/EmployeeList";

const Favorite = () => {
    return (
        <div>
            <EmployeeList/>
        </div>
    )
}
export default Favorite;